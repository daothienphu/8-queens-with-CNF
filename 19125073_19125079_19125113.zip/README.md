# 8-queens-with-CNF
Open a terminal in the `.\source_code` folder and run `python main.py`.

In the prompted `Task: `  input a task c, d, or f.

For task c, input the coordinates of the point that you want to retrieve the CNF clause.
The input should be in the form `x y`.

For task f, the program will open another program in which you can press `Input queens` and select the `input.txt` file.
After selecting, the program will automatically place the queens to their correct positions.
You can also select `Solve` and the program will place the queens step by step to get the solution for the 8-queen problem.